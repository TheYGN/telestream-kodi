"""Runs in the background while Kodi is open.

Two jobs:
- tell the server this TV exists and play what the library page sends it (a background thread);
- near the end of an episode, offer the next one in a small card over the video (the main loop).
"""

import json
import threading
import time
import uuid
from urllib.parse import quote, urlsplit
from urllib.request import Request, urlopen

import xbmc
import xbmcaddon
import xbmcgui

WAIT_SECONDS = 15  # one request stays open this long; short, so closing Kodi is never held up
ADDON_PATH = xbmcaddon.Addon().getAddonInfo("path")


def settings():
    addon = xbmcaddon.Addon()  # fresh each time, so changed settings are picked up
    server = (addon.getSetting("server") or "http://192.168.7.7:8765").rstrip("/")
    tv_id = addon.getSetting("tv_id")
    if not tv_id:
        tv_id = uuid.uuid4().hex
        addon.setSetting("tv_id", tv_id)
    name = addon.getSetting("tv_name") or xbmc.getInfoLabel("System.FriendlyName") or "טלוויזיה"
    try:
        lead = max(20, int(addon.getSetting("next_lead") or 90))
    except ValueError:
        lead = 90
    return server, tv_id, name, lead


def get_json(url: str, timeout: float = 10):
    with urlopen(url, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8") or "{}")


def post_json(url: str, data: dict) -> None:
    request = Request(url, data=json.dumps(data).encode("utf-8"), headers={"Content-Type": "application/json"})
    with urlopen(request, timeout=10) as resp:
        resp.read()


def play(server: str, item: dict) -> None:
    listitem = xbmcgui.ListItem(item.get("title") or "")
    poster = item.get("poster") or ""
    if poster:
        poster = server + poster if poster.startswith("/") else poster
        listitem.setArt({"thumb": poster, "poster": poster})
    listitem.getVideoInfoTag().setTitle(item.get("title") or "")
    xbmc.Player().play(server + item["path"], listitem)


# ---------- sent from the library page ----------

def listen_for_plays(monitor: xbmc.Monitor) -> None:
    announced = None
    while not monitor.abortRequested():
        server, tv_id, name, _ = settings()
        try:
            if announced != (server, name):
                post_json(server + "/api/tv/hello", {"id": tv_id, "name": name})
                announced = (server, name)
            item = get_json(f"{server}/api/tv/{tv_id}/wait?timeout={WAIT_SECONDS}", timeout=WAIT_SECONDS + 10)
            if item.get("path"):
                play(server, item)
        except Exception as e:  # server restarting or PC off: try again shortly
            if "404" in str(e):
                announced = None  # the server forgot this TV; say hello again
            xbmc.log(f"TeleStream service: {e}", xbmc.LOGDEBUG)
            if monitor.waitForAbort(10):
                break


# ---------- "next episode" card ----------

class NextCard(xbmcgui.WindowXMLDialog):
    choice = None  # "now" or "cancel"

    def onClick(self, control_id):
        self.choice = "now" if control_id == 20 else "cancel"
        self.close()

    def onAction(self, action):
        if action.getId() in (xbmcgui.ACTION_NAV_BACK, xbmcgui.ACTION_PREVIOUS_MENU):
            self.choice = "cancel"
            self.close()


class Watcher(xbmc.Player):
    """Remembers whether the last episode ran to its end (not stopped by the viewer)."""

    def __init__(self):
        super().__init__()
        self.ended = False

    def onPlayBackEnded(self):
        self.ended = True


def next_item(nxt: dict) -> dict:
    label = f"{nxt['show']} · עונה {nxt['season']} פרק {nxt['episode']}"
    return {"path": nxt["path"], "title": label + (f" · {nxt['name']}" if nxt.get("name") else ""), "poster": nxt.get("poster")}


SETTLE_SECONDS = 12  # right after a switch Kodi can still report the old file's times; don't trust them yet


def watch_episodes(monitor: xbmc.Monitor) -> None:
    player = Watcher()
    current = None   # file now playing
    upcoming = None  # what the server says comes next, or None
    card = None
    decided = None   # "now", "cancel", or None (card shown, no button pressed: play next at the end)
    offered = False
    started = 0.0    # when the current file was first seen
    while not monitor.waitForAbort(1):
        server, _, _, lead = settings()
        if player.ended and offered and upcoming and decided is None:  # ran to the end with the card up
            player.ended = False
            offered = False
            if card:
                card.close()
                card = None
            play(server, next_item(upcoming))
            continue
        player.ended = False
        if not player.isPlayingVideo():
            if card:
                card.close()
                card = None
            continue
        try:
            playing = player.getPlayingFile()
        except RuntimeError:
            continue
        if playing != current:  # a new file started: look up what follows it
            if card:
                card.close()
                card = None
            current, upcoming, decided, offered, started = playing, None, None, False, time.monotonic()
            if playing.startswith(server + "/stream/"):
                try:
                    found = get_json(f"{server}/api/next?path={quote(urlsplit(playing).path, safe='')}")
                    upcoming = found if found.get("path") else None
                except Exception as e:
                    xbmc.log(f"TeleStream next episode: {e}", xbmc.LOGDEBUG)
        if not upcoming or time.monotonic() - started < SETTLE_SECONDS:
            continue
        try:
            total, now = player.getTotalTime(), player.getTime()
        except RuntimeError:
            continue
        left = total - now
        if left > lead + 20 and (offered or decided):  # the viewer went back: offer again when the end comes
            if card:
                card.close()
                card = None
            offered, decided = False, None
        if decided or total < lead * 3 or left > lead:  # very short videos never get the card
            continue
        if not offered:
            card = NextCard("telestream-next.xml", ADDON_PATH, "default", "1080i")
            card.setProperty("show", upcoming["show"])
            card.setProperty("episode", f"עונה {upcoming['season']} פרק {upcoming['episode']}"
                                        + (f" · {upcoming['name']}" if upcoming.get("name") else ""))
            still = upcoming.get("still") or ""
            card.setProperty("still", server + still if still.startswith("/") else still)
            card.show()
            offered = True
        if card:
            card.setProperty("countdown", f"מתחיל אוטומטית בעוד {int(max(left, 0)) // 60}:{int(max(left, 0)) % 60:02d}")
            if card.choice:
                decided = card.choice
                card = None
                if decided == "now":
                    play(server, next_item(upcoming))


def main() -> None:
    monitor = xbmc.Monitor()
    threading.Thread(target=listen_for_plays, args=(monitor,), daemon=True).start()
    watch_episodes(monitor)


main()
