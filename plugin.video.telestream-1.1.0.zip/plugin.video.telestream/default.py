"""TeleStream for Kodi: menus of movies and series from the TeleStream server on the home PC."""

import json
import sys
from urllib.parse import parse_qsl, quote, urlencode
from urllib.request import urlopen

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]


def server() -> str:
    return (ADDON.getSetting("server") or "http://192.168.7.7:8765").rstrip("/")


def plugin_url(**params) -> str:
    return f"{BASE_URL}?{urlencode(params)}"


def api(path: str, **params):
    """Ask the server; on failure tell the viewer once and return None."""
    params = {k: v for k, v in params.items() if v not in (None, "")}
    url = server() + path + (f"?{urlencode(params)}" if params else "")
    try:
        with urlopen(url, timeout=30) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except Exception as e:
        xbmc.log(f"TeleStream: {url} failed: {e}", xbmc.LOGWARNING)
        xbmcgui.Dialog().ok("TeleStream", "השרת במחשב לא עונה.[CR]ודא שהמחשב דלוק ונסה שוב.")
        return None


def add_folder(label: str, url: str, art: dict | None = None, plot: str = "") -> None:
    item = xbmcgui.ListItem(label)
    if art:
        item.setArt(art)
    if plot:
        item.getVideoInfoTag().setPlot(plot)
    xbmcplugin.addDirectoryItem(HANDLE, url, item, isFolder=True)


def describe(item: xbmcgui.ListItem, info: dict, mediatype: str) -> None:
    tag = item.getVideoInfoTag()
    tag.setMediaType(mediatype)
    tag.setTitle(info.get("title") or "")
    if info.get("original_title"):
        tag.setOriginalTitle(info["original_title"])
    if info.get("year"):
        tag.setYear(int(info["year"]))
    tag.setPlot(info.get("overview") or "")
    if info.get("genres"):
        tag.setGenres(info["genres"])
    if info.get("rating"):
        tag.setRating(float(info["rating"]))
    ids = {"tmdb": str(info["tmdb_id"])} if info.get("tmdb_id") else {}
    if info.get("imdb_id"):
        ids["imdb"] = info["imdb_id"]
    if ids:
        tag.setUniqueIDs(ids, "tmdb")
    item.setArt({
        "poster": info.get("poster") or "",
        "thumb": info.get("poster") or "",
        "fanart": info.get("fanart") or "",
    })


def playable(item: xbmcgui.ListItem, files: list) -> str:
    """Mark the item playable; with several copies or parts, Kodi asks which one."""
    item.setProperty("IsPlayable", "true")
    if files and files[0].get("duration"):
        item.getVideoInfoTag().setDuration(int(files[0]["duration"]))
    return plugin_url(action="play", files=json.dumps([f["path"] for f in files]), labels=json.dumps(
        [f"{f['name']}  ({f['size'] / 1024 ** 3:.1f} GB · {f['group']})" for f in files]
    ))


def next_page(data: dict, params: dict) -> None:
    if data["page"] < data["pages"]:
        following = dict(params, page=str(data["page"] + 1))
        add_folder(f"[B]עמוד הבא ({data['page'] + 1} מתוך {data['pages']})[/B]", plugin_url(**following))


# ---------- menus ----------

def root() -> None:
    home = api("/api/home")
    if home is None:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    add_folder(f"סרטים ({home['movies']})", plugin_url(action="movies"))
    add_folder("סרטים לפי ז'אנר", plugin_url(action="genres", kind="movies"))
    add_folder(f"סדרות ({home['shows']})", plugin_url(action="shows"))
    add_folder("סדרות לפי ז'אנר", plugin_url(action="genres", kind="shows"))
    add_folder("חיפוש", plugin_url(action="search"))
    add_folder(f"קבצים שלא זוהו ({home['other']})", plugin_url(action="other"))
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def genres(kind: str) -> None:
    home = api("/api/home")
    if home is None:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    for genre, count in home["movie_genres" if kind == "movies" else "show_genres"]:
        add_folder(f"{genre} ({count})", plugin_url(action=kind, genre=genre))
    xbmcplugin.endOfDirectory(HANDLE)


def movies(params: dict) -> None:
    data = api("/api/movies", page=params.get("page"), genre=params.get("genre"), q=params.get("q"))
    if data is None:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    xbmcplugin.setContent(HANDLE, "movies")
    for movie in data["items"]:
        item = xbmcgui.ListItem(movie["title"])
        describe(item, movie, "movie")
        xbmcplugin.addDirectoryItem(HANDLE, playable(item, movie["files"]), item, isFolder=False)
    next_page(data, params)
    xbmcplugin.endOfDirectory(HANDLE)


def shows(params: dict) -> None:
    data = api("/api/shows", page=params.get("page"), genre=params.get("genre"), q=params.get("q"))
    if data is None:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    xbmcplugin.setContent(HANDLE, "tvshows")
    for show in data["items"]:
        item = xbmcgui.ListItem(show["title"])
        describe(item, show, "tvshow")
        xbmcplugin.addDirectoryItem(HANDLE, plugin_url(action="seasons", show=show["key"]), item, isFolder=True)
    next_page(data, params)
    xbmcplugin.endOfDirectory(HANDLE)


def load_show(key: str):
    return api("/api/show/" + quote(key, safe=""))


def seasons(key: str) -> None:
    show = load_show(key)
    if show is None:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    xbmcplugin.setContent(HANDLE, "seasons")
    for number in sorted(show["seasons"], key=int):
        season = show["seasons"][number]
        item = xbmcgui.ListItem(f"עונה {number}")
        describe(item, show, "season")
        tag = item.getVideoInfoTag()
        tag.setTitle(f"עונה {number}")
        tag.setSeason(int(number))
        tag.setTvShowTitle(show["title"])
        if season.get("poster"):
            item.setArt({"poster": season["poster"], "thumb": season["poster"], "fanart": show.get("fanart") or ""})
        xbmcplugin.addDirectoryItem(HANDLE, plugin_url(action="episodes", show=key, season=number), item, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)


def episodes(key: str, number: str) -> None:
    show = load_show(key)
    if show is None:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    season = show["seasons"][number]
    xbmcplugin.setContent(HANDLE, "episodes")
    for episode_number in sorted(season["episodes"], key=int):
        episode = season["episodes"][episode_number]
        name = episode.get("name") or f"פרק {episode_number}"
        item = xbmcgui.ListItem(f"{episode_number}. {name}")
        tag = item.getVideoInfoTag()
        tag.setMediaType("episode")
        tag.setTitle(name)
        tag.setTvShowTitle(show["title"])
        tag.setSeason(int(number))
        tag.setEpisode(int(episode_number))
        tag.setPlot(episode.get("overview") or show.get("overview") or "")
        if episode.get("aired"):
            tag.setFirstAired(episode["aired"])
        poster = season.get("poster") or show.get("poster") or ""
        item.setArt({"thumb": episode.get("still") or poster, "poster": poster, "fanart": show.get("fanart") or ""})
        xbmcplugin.addDirectoryItem(HANDLE, playable(item, episode["files"]), item, isFolder=False)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_EPISODE)
    xbmcplugin.endOfDirectory(HANDLE)


def other(params: dict) -> None:
    data = api("/api/other", page=params.get("page"), q=params.get("q"))
    if data is None:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    xbmcplugin.setContent(HANDLE, "videos")
    for entry in data["items"]:
        item = xbmcgui.ListItem(entry["name"])
        item.getVideoInfoTag().setTitle(entry["name"])
        item.getVideoInfoTag().setPlot(f"{entry['group']}[CR]{entry['size'] / 1024 ** 3:.1f} GB")
        xbmcplugin.addDirectoryItem(HANDLE, playable(item, [entry]), item, isFolder=False)
    next_page(data, params)
    xbmcplugin.endOfDirectory(HANDLE)


def search(params: dict) -> None:
    query = params.get("q") or xbmcgui.Dialog().input("חיפוש סרט או סדרה")
    if not query:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    add_folder(f"סרטים: {query}", plugin_url(action="movies", q=query))
    add_folder(f"סדרות: {query}", plugin_url(action="shows", q=query))
    add_folder(f"קבצים שלא זוהו: {query}", plugin_url(action="other", q=query))
    xbmcplugin.endOfDirectory(HANDLE)


def play(params: dict) -> None:
    paths = json.loads(params["files"])
    choice = 0
    if len(paths) > 1:
        choice = xbmcgui.Dialog().select("באיזה קובץ לנגן?", json.loads(params["labels"]))
        if choice < 0:
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return
    xbmcplugin.setResolvedUrl(HANDLE, True, xbmcgui.ListItem(path=server() + paths[choice]))


def main() -> None:
    params = dict(parse_qsl(sys.argv[2][1:]))
    action = params.get("action")
    if action is None:
        root()
    elif action == "play":
        play(params)
    elif action == "genres":
        genres(params["kind"])
    elif action == "movies":
        movies(params)
    elif action == "shows":
        shows(params)
    elif action == "seasons":
        seasons(params["show"])
    elif action == "episodes":
        episodes(params["show"], params["season"])
    elif action == "other":
        other(params)
    elif action == "search":
        search(params)


main()
