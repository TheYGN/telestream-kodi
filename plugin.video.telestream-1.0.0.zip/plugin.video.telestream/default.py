"""TeleStream for Kodi: menus of movies and series from the TeleStream server on the home PC."""

import json
import os
import sys
import time
from urllib.parse import parse_qsl, urlencode
from urllib.request import urlopen

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
CACHE_FILE = os.path.join(xbmcvfs.translatePath(ADDON.getAddonInfo("profile")), "catalog.json")
CACHE_SECONDS = 5 * 60


def server() -> str:
    return (ADDON.getSetting("server") or "http://192.168.7.7:8765").rstrip("/")


def plugin_url(**params) -> str:
    return f"{BASE_URL}?{urlencode(params)}"


def load_catalog(refresh: bool = False) -> dict | None:
    """The catalog from the server, kept for a few minutes so moving between menus is instant."""
    if not refresh and os.path.exists(CACHE_FILE) and time.time() - os.path.getmtime(CACHE_FILE) < CACHE_SECONDS:
        with open(CACHE_FILE, encoding="utf-8") as f:
            return json.load(f)
    try:
        with urlopen(server() + "/api/catalog", timeout=30) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except Exception as e:
        xbmc.log(f"TeleStream: cannot reach server: {e}", xbmc.LOGWARNING)
        xbmcgui.Dialog().ok("TeleStream", "השרת במחשב לא עונה.[CR]ודא שהמחשב דלוק ונסה שוב.")
        return None
    os.makedirs(os.path.dirname(CACHE_FILE), exist_ok=True)
    with open(CACHE_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False)
    return data


def add_folder(label: str, url: str, art: dict | None = None) -> None:
    item = xbmcgui.ListItem(label)
    if art:
        item.setArt(art)
    xbmcplugin.addDirectoryItem(HANDLE, url, item, isFolder=True)


def describe(item: xbmcgui.ListItem, info: dict, mediatype: str) -> None:
    tag = item.getVideoInfoTag()
    tag.setMediaType(mediatype)
    tag.setTitle(info.get("title") or "")
    if info.get("original_title"):
        tag.setOriginalTitle(info["original_title"])
    if info.get("year"):
        tag.setYear(int(info["year"]))
    tag.setPlot(info.get("overview") or "")
    if info.get("genres"):
        tag.setGenres(info["genres"])
    if info.get("rating"):
        tag.setRating(float(info["rating"]))
    ids = {"tmdb": str(info["tmdb_id"])} if info.get("tmdb_id") else {}
    if info.get("imdb_id"):
        ids["imdb"] = info["imdb_id"]
    if ids:
        tag.setUniqueIDs(ids, "tmdb")
    item.setArt({
        "poster": info.get("poster") or "",
        "thumb": info.get("poster") or "",
        "fanart": info.get("fanart") or "",
    })


def playable(item: xbmcgui.ListItem, files: list) -> str:
    """Mark the item playable; with several copies of the same video, Kodi asks which one."""
    item.setProperty("IsPlayable", "true")
    tag = item.getVideoInfoTag()
    if files and files[0].get("duration"):
        tag.setDuration(int(files[0]["duration"]))
    return plugin_url(action="play", files=json.dumps([f["path"] for f in files]), labels=json.dumps(
        [f"{f['name']}  ({f['size'] / 1024 ** 3:.1f} GB · {f['group']})" for f in files]
    ))


# ---------- menus ----------

def root() -> None:
    add_folder("סרטים", plugin_url(action="movies"))
    add_folder("סדרות", plugin_url(action="shows"))
    add_folder("קבצים שלא זוהו", plugin_url(action="other"))
    add_folder("רענון הרשימות", plugin_url(action="refresh"))
    xbmcplugin.endOfDirectory(HANDLE)


def movies(catalog: dict) -> None:
    xbmcplugin.setContent(HANDLE, "movies")
    for movie in catalog["movies"]:
        item = xbmcgui.ListItem(movie["title"])
        describe(item, movie, "movie")
        url = playable(item, movie["files"])
        xbmcplugin.addDirectoryItem(HANDLE, url, item, isFolder=False)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_YEAR)
    xbmcplugin.endOfDirectory(HANDLE)


def find_show(catalog: dict, tmdb_id: str) -> dict:
    return next(s for s in catalog["shows"] if str(s["tmdb_id"]) == tmdb_id)


def shows(catalog: dict) -> None:
    xbmcplugin.setContent(HANDLE, "tvshows")
    for show in catalog["shows"]:
        item = xbmcgui.ListItem(show["title"])
        describe(item, show, "tvshow")
        xbmcplugin.addDirectoryItem(HANDLE, plugin_url(action="seasons", show=show["tmdb_id"]), item, isFolder=True)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL)
    xbmcplugin.endOfDirectory(HANDLE)


def seasons(catalog: dict, tmdb_id: str) -> None:
    show = find_show(catalog, tmdb_id)
    xbmcplugin.setContent(HANDLE, "seasons")
    for number in sorted(show["seasons"], key=int):
        season = show["seasons"][number]
        item = xbmcgui.ListItem(f"עונה {number}")
        describe(item, show, "season")
        tag = item.getVideoInfoTag()
        tag.setTitle(f"עונה {number}")
        tag.setSeason(int(number))
        tag.setTvShowTitle(show["title"])
        if season.get("poster"):
            item.setArt({"poster": season["poster"], "thumb": season["poster"], "fanart": show.get("fanart") or ""})
        url = plugin_url(action="episodes", show=tmdb_id, season=number)
        xbmcplugin.addDirectoryItem(HANDLE, url, item, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)


def episodes(catalog: dict, tmdb_id: str, number: str) -> None:
    show = find_show(catalog, tmdb_id)
    season = show["seasons"][number]
    xbmcplugin.setContent(HANDLE, "episodes")
    for episode_number in sorted(season["episodes"], key=int):
        episode = season["episodes"][episode_number]
        name = episode.get("name") or f"פרק {episode_number}"
        item = xbmcgui.ListItem(f"{episode_number}. {name}")
        tag = item.getVideoInfoTag()
        tag.setMediaType("episode")
        tag.setTitle(name)
        tag.setTvShowTitle(show["title"])
        tag.setSeason(int(number))
        tag.setEpisode(int(episode_number))
        tag.setPlot(episode.get("overview") or show.get("overview") or "")
        if episode.get("aired"):
            tag.setFirstAired(episode["aired"])
        still = episode.get("still") or season.get("poster") or show.get("poster") or ""
        item.setArt({"thumb": still, "poster": season.get("poster") or show.get("poster") or "",
                     "fanart": show.get("fanart") or ""})
        url = playable(item, episode["files"])
        xbmcplugin.addDirectoryItem(HANDLE, url, item, isFolder=False)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_EPISODE)
    xbmcplugin.endOfDirectory(HANDLE)


def other(catalog: dict) -> None:
    xbmcplugin.setContent(HANDLE, "videos")
    for entry in catalog["other"]:
        item = xbmcgui.ListItem(entry["name"])
        item.getVideoInfoTag().setTitle(entry["name"])
        item.getVideoInfoTag().setPlot(f"{entry['group']}[CR]{entry['size'] / 1024 ** 3:.1f} GB")
        url = playable(item, [entry])
        xbmcplugin.addDirectoryItem(HANDLE, url, item, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE)


def play(params: dict) -> None:
    paths = json.loads(params["files"])
    choice = 0
    if len(paths) > 1:
        choice = xbmcgui.Dialog().select("באיזה קובץ לנגן?", json.loads(params["labels"]))
        if choice < 0:
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return
    xbmcplugin.setResolvedUrl(HANDLE, True, xbmcgui.ListItem(path=server() + paths[choice]))


def main() -> None:
    params = dict(parse_qsl(sys.argv[2][1:]))
    action = params.get("action")
    if action is None:
        return root()
    if action == "play":
        return play(params)
    if action == "refresh":
        if load_catalog(refresh=True) is not None:
            xbmcgui.Dialog().notification("TeleStream", "הרשימות עודכנו", time=3000)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    catalog = load_catalog()
    if catalog is None:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    if action == "movies":
        movies(catalog)
    elif action == "shows":
        shows(catalog)
    elif action == "seasons":
        seasons(catalog, params["show"])
    elif action == "episodes":
        episodes(catalog, params["show"], params["season"])
    elif action == "other":
        other(catalog)


main()
