"""Runs in the background while Kodi is open: tells the server this TV exists and plays what it is sent."""

import json
import uuid
from urllib.request import Request, urlopen

import xbmc
import xbmcaddon
import xbmcgui

WAIT_SECONDS = 15  # one request stays open this long; short, so closing Kodi is never held up


def settings():
    addon = xbmcaddon.Addon()  # fresh each time, so a renamed TV is picked up
    server = (addon.getSetting("server") or "http://192.168.7.7:8765").rstrip("/")
    tv_id = addon.getSetting("tv_id")
    if not tv_id:
        tv_id = uuid.uuid4().hex
        addon.setSetting("tv_id", tv_id)
    name = addon.getSetting("tv_name") or xbmc.getInfoLabel("System.FriendlyName") or "טלוויזיה"
    return server, tv_id, name


def post_json(url: str, data: dict) -> None:
    request = Request(url, data=json.dumps(data).encode("utf-8"), headers={"Content-Type": "application/json"})
    with urlopen(request, timeout=10) as resp:
        resp.read()


def play(server: str, item: dict) -> None:
    listitem = xbmcgui.ListItem(item.get("title") or "")
    if item.get("poster"):
        listitem.setArt({"thumb": item["poster"], "poster": item["poster"]})
    listitem.getVideoInfoTag().setTitle(item.get("title") or "")
    xbmc.Player().play(server + item["path"], listitem)


def main() -> None:
    monitor = xbmc.Monitor()
    announced = None
    while not monitor.abortRequested():
        server, tv_id, name = settings()
        try:
            if announced != (server, name):
                post_json(server + "/api/tv/hello", {"id": tv_id, "name": name})
                announced = (server, name)
            with urlopen(f"{server}/api/tv/{tv_id}/wait?timeout={WAIT_SECONDS}", timeout=WAIT_SECONDS + 10) as resp:
                item = json.loads(resp.read().decode("utf-8") or "{}")
            if item.get("path"):
                play(server, item)
        except Exception as e:  # server restarting or PC off: try again shortly
            if "404" in str(e):
                announced = None  # the server forgot this TV; say hello again
            xbmc.log(f"TeleStream service: {e}", xbmc.LOGDEBUG)
            if monitor.waitForAbort(10):
                break


main()
